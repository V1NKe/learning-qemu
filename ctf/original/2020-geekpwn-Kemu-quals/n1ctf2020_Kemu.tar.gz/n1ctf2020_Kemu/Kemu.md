### Kemu

题目名称：

comagain



题目描述：

Have you learned pci device?



题目flag：

n1ctf{Oh_Y0U_C4NGETTHE_MS1X_SECRET_TH4T_50_GREAT}



题目附件：

pwn.tar.gz



题目信息：

IP：8.210.166.195

USR：pwn

PASSWD：pwn
