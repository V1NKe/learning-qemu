## V1NKe's QEMU

题目描述：

V1NKe的Ubuntu18.04最近有了一个新问题，运行在上面的QEMU总是莫名其妙的出现崩溃，无奈之下，被迫掏出gdb调试了一波，发现问题出在QEMU的Slirp模块处理TCP/IP协议过程中。经过谷歌之后，发现这个情况跟一个CVE类似，但是仔细研究之后又有些许的不一样。研究透彻之后，V1NKe打算自己动手写一个exploit脚本。



注释：

1. 如果你需要自己编译一个QEMU调试的话，最好用给出文件夹中的qemu-5.0.1.zip编。
2. 构建文件系统的create-image.sh脚本已给出。（当然可以自己选择用busybox）
3. 比赛中不开放nc，如已做出，请直接询问工作人员，由工作人员带你去服务器上跑exp。



关于缺失库文件：

一般来说，缺失的库文件只要`apt search xxxxxx`，随后`install`带`-dev`后缀的库文件就可以。

如果遇到缺失的是`libiscsi.so.9.0.0`，这个库文件已经在文件夹中给出，执行一下：

```
sudo cp libiscsi.so.9.0.0 /usr/local/lib/
sudo ln -s /usr/local/lib/libiscsi.so.9.0.0 /usr/local/lib/libiscsi.so
sudo ln -s /usr/local/lib/libiscsi.so.9.0.0 /lib/x86_64-linux-gnu/libiscsi.so.9
```

就OK了。



别的坑点应该...没有了（真**坑啊



Have Fun！（顺便打个广告：有兴趣搞虚拟化的选手欢迎加入啊！）