#/bin/bash
set -e
insmod exp.ko
